/** Clockwork Debugger JS **/
document.addEventListener("DOMContentLoaded",function () {
    var e=document.createElement("div");e.appendChild(document.createElement("i")),e.className="clockwork-badge",document.body.appendChild(e)});
